from fastapi.testclient import TestClient
from main import app


def test_home():
    client = TestClient(app)
    response = client.get('/')
    assert response.status_code == 200
    assert 'EduGenie' in response.text


def test_health():
    client = TestClient(app)
    response = client.get('/health')
    assert response.status_code == 200
    assert response.json()['status'] == 'ok'
