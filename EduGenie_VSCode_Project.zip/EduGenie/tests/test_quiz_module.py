import pytest
from quiz_module import _clean_json_block, _validate_quiz


def test_clean_json_block():
    raw = '```json\n{"questions": []}\n```'
    assert _clean_json_block(raw) == '{"questions": []}'


def test_validate_quiz_requires_three_questions():
    with pytest.raises(ValueError):
        _validate_quiz({"questions": []})


def test_validate_quiz_accepts_valid_data():
    q = {"questions": [{"question": "2+2?", "options": ["1", "2", "3", "4"], "correct_answer": "4"}] * 3}
    assert _validate_quiz(q) == q
