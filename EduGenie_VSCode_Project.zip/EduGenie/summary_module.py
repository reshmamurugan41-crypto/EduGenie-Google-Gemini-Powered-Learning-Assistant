from gemini_client import generate_text


def summarize_text(text: str) -> str:
    prompt = f"""Summarize the educational passage below for quick revision.
Keep the essential facts and relationships, remove repetition, and use simple language.
Return a concise summary with a short heading and bullet points where useful.
Passage:
{text}
"""
    return generate_text(prompt)
