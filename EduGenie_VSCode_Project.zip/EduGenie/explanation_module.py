"""Concept explanation module.

The project documentation specifies LaMini-Flan-T5 for explanations. The model is
loaded lazily so the web server starts quickly. Set USE_LOCAL_EXPLAINER=true to
use it; otherwise Gemini provides the explanation without requiring a large local
model download.
"""
import os
from functools import lru_cache


def _local_explain(topic: str) -> str:
    from transformers import pipeline

    generator = _get_local_pipeline()
    prompt = (
        "Explain the following educational topic simply for a beginner. "
        "Use short sections and one simple example. Topic: " + topic
    )
    result = generator(prompt, max_new_tokens=220, do_sample=False)
    return result[0]["generated_text"].strip()


@lru_cache(maxsize=1)
def _get_local_pipeline():
    model_name = os.getenv("LOCAL_EXPLAINER_MODEL", "MBZUAI/LaMini-Flan-T5-783M")
    from transformers import pipeline
    return pipeline("text2text-generation", model=model_name, device=-1)


def explain_concept(topic: str) -> str:
    if os.getenv("USE_LOCAL_EXPLAINER", "false").lower() == "true":
        try:
            return _local_explain(topic)
        except Exception as exc:
            if os.getenv("ALLOW_GEMINI_EXPLANATION_FALLBACK", "true").lower() != "true":
                raise RuntimeError(f"Local explanation model failed: {exc}") from exc

    from gemini_client import generate_text
    prompt = f"""You are EduGenie, an educational tutor.
Explain the topic below for a learner who may be new to it.
Requirements:
- Use plain, friendly language.
- Start with a one-sentence definition.
- Explain the key ideas in bullets.
- Give one simple example or analogy.
- Keep it concise (about 180-250 words).
Topic: {topic}
"""
    return generate_text(prompt)
