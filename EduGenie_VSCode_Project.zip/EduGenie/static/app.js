const task = document.getElementById('task');
const input = document.getElementById('inputText');
const level = document.getElementById('level');
const levelLabel = document.getElementById('level-label');
const submit = document.getElementById('submitBtn');
const result = document.getElementById('result');
const status = document.getElementById('status');
const copyBtn = document.getElementById('copyBtn');
let latestText = '';

const placeholders = {
  qa: 'Example: What is the largest ocean?',
  explain: 'Example: Explain the Pythagoras theorem',
  quiz: 'Paste a lesson, paragraph, or study passage here...',
  summarize: 'Paste a long educational passage here...',
  learn: 'Example: SQL'
};

task.addEventListener('change', () => {
  input.placeholder = placeholders[task.value];
  const showLevel = task.value === 'learn';
  level.classList.toggle('hidden', !showLevel);
  levelLabel.classList.toggle('hidden', !showLevel);
});

function renderQuiz(quiz) {
  result.classList.remove('muted');
  result.innerHTML = '';
  quiz.questions.forEach((q, i) => {
    const box = document.createElement('div');
    box.className = 'quiz-question';
    const title = document.createElement('strong');
    title.textContent = `${i + 1}. ${q.question}`;
    box.appendChild(title);
    q.options.forEach(option => {
      const label = document.createElement('label');
      label.className = 'quiz-option';
      const radio = document.createElement('input');
      radio.type = 'radio'; radio.name = `q-${i}`; radio.value = option;
      label.appendChild(radio); label.appendChild(document.createTextNode(option));
      box.appendChild(label);
    });
    const feedback = document.createElement('div');
    feedback.className = 'feedback';
    const check = document.createElement('button');
    check.className = 'secondary'; check.textContent = 'Check answer';
    check.addEventListener('click', () => {
      const selected = box.querySelector(`input[name="q-${i}"]:checked`);
      if (!selected) { feedback.textContent = 'Choose an option first.'; return; }
      feedback.textContent = selected.value === q.correct_answer ? '✓ Correct!' : `✗ Correct answer: ${q.correct_answer}`;
    });
    box.appendChild(check); box.appendChild(feedback); result.appendChild(box);
  });
}

async function run() {
  const text = input.value.trim();
  if (!text) { result.textContent = 'Please enter some text first.'; return; }
  submit.disabled = true; copyBtn.disabled = true; status.textContent = 'Working…';
  result.className = 'result muted'; result.textContent = 'Generating your response…';
  const routes = { qa: '/qa', explain: '/explain', quiz: '/quiz', summarize: '/summarize', learn: '/learn/recommendations' };
  const bodies = {
    qa: { question: text }, explain: { topic: text }, quiz: { text }, summarize: { text }, learn: { topic: text, level: level.value }
  };
  try {
    const response = await fetch(routes[task.value], { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(bodies[task.value]) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'Request failed');
    if (task.value === 'quiz') renderQuiz(data.quiz);
    else {
      latestText = data.answer || data.explanation || data.summary || data.recommendations || '';
      result.className = 'result'; result.textContent = latestText;
      copyBtn.disabled = !latestText;
    }
    status.textContent = 'Ready';
  } catch (err) {
    result.className = 'result'; result.textContent = `Error: ${err.message}`; status.textContent = 'Error';
  } finally { submit.disabled = false; }
}

submit.addEventListener('click', run);
copyBtn.addEventListener('click', async () => { if (latestText) await navigator.clipboard.writeText(latestText); copyBtn.textContent = 'Copied'; setTimeout(() => copyBtn.textContent = 'Copy', 1200); });
input.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') run(); });
