# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight FastAPI web application based on the supplied project documentation. It provides:

- Question & Answer (`/qa`)
- Concept explanation (`/explain`)
- 3-question MCQ quiz generation (`/quiz`)
- Text summarization (`/summarize`)
- Beginner-to-advanced learning paths (`/learn/recommendations`)

The original document specifies Gemini 1.5 Pro and LaMini-Flan-T5-783M. The project uses the current Google Gen AI Python SDK with a configurable Gemini model, defaulting to `gemini-2.5-flash`. The LaMini model remains available as an optional local explanation backend; Gemini fallback is enabled by default so the application is practical to run locally.

## 1. Prerequisites

- Python 3.10 or newer
- VS Code
- A Gemini API key from Google AI Studio
- Internet access for Gemini API calls

## 2. Open in VS Code

Extract the ZIP, then open the `EduGenie` folder in VS Code.

### Windows PowerShell

```powershell
cd path\to\EduGenie
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Open `.env` and replace `your_gemini_api_key_here` with your real API key.

### macOS/Linux

```bash
cd path/to/EduGenie
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

## 3. Run

```bash
uvicorn main:app --reload
```

Open http://127.0.0.1:8000 in a browser.

API health check: http://127.0.0.1:8000/health

FastAPI interactive API docs: http://127.0.0.1:8000/docs

## 4. Test the application

1. Choose **Question & Answer** and ask `Which is the largest ocean?`.
2. Choose **Explain a Concept** and enter `Pythagoras theorem`.
3. Choose **Summarize Text** and paste a paragraph.
4. Choose **Generate Quiz** and paste study material. The UI generates three questions and lets the learner check each answer.
5. Choose **Learning Path**, select a level, and enter `SQL`.

Run automated tests with:

```bash
pytest -q
```

## 5. Optional local LaMini explanation model

The documentation describes LaMini-Flan-T5-783M as the local explanation model. To enable it, edit `.env`:

```env
USE_LOCAL_EXPLAINER=true
```

The first explanation request may download the model from Hugging Face and requires substantial disk/RAM. If loading fails and `ALLOW_GEMINI_EXPLANATION_FALLBACK=true`, EduGenie automatically uses Gemini instead.

## Project structure

```text
EduGenie/
├── main.py
├── gemini_client.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── app.js
│   └── style.css
└── tests/
    ├── test_quiz_module.py
    └── test_routes.py
```

## API examples

### Q&A

```bash
curl -X POST http://127.0.0.1:8000/qa -H "Content-Type: application/json" -d "{\"question\":\"What is photosynthesis?\"}"
```

### Quiz

```bash
curl -X POST http://127.0.0.1:8000/quiz -H "Content-Type: application/json" -d "{\"text\":\"Photosynthesis converts light energy into chemical energy in plants.\"}"
```

## Troubleshooting

- **GEMINI_API_KEY is not configured:** make sure `.env` exists beside `main.py` and contains a valid key.
- **ModuleNotFoundError:** activate `.venv` and run `pip install -r requirements.txt`.
- **PowerShell blocks activation:** run `Set-ExecutionPolicy -Scope Process Bypass` for the current terminal, then activate the environment again.
- **Port 8000 is busy:** run `uvicorn main:app --reload --port 8001` and open http://127.0.0.1:8001.
- **Gemini quota/API errors:** verify the API key and its available quota in Google AI Studio.
