from gemini_client import generate_text


def get_learning_recommendations(topic: str, level: str = "beginner") -> str:
    prompt = f"""Create a personalized learning path for the topic: {topic}
Learner level: {level}

Organize it from foundational to advanced concepts. Include:
1. A short goal statement.
2. 5-8 ordered stages with concepts to learn.
3. An approximate timeline for each stage.
4. Practical exercises or mini-projects.
5. Suggested resource types (videos, articles, books, documentation). Do not invent specific URLs.
6. A final self-assessment checklist.
Keep the plan practical and readable.
"""
    return generate_text(prompt)
