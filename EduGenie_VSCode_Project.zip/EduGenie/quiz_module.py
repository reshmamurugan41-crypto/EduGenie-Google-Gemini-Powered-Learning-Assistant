"""Quiz generation with strict JSON parsing and validation."""
import json
import re

from gemini_client import generate_text


def _clean_json_block(raw: str) -> str:
    cleaned = raw.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ValueError("No JSON object found in model response.")
    return cleaned[start:end + 1]


def _validate_quiz(data):
    if not isinstance(data, dict) or not isinstance(data.get("questions"), list):
        raise ValueError("Quiz JSON must contain a questions array.")
    if len(data["questions"]) != 3:
        raise ValueError("Quiz must contain exactly 3 questions.")
    for q in data["questions"]:
        if not isinstance(q, dict):
            raise ValueError("Each question must be an object.")
        if not isinstance(q.get("question"), str) or not q["question"].strip():
            raise ValueError("Each question needs question text.")
        options = q.get("options")
        if not isinstance(options, list) or len(options) != 4 or not all(isinstance(x, str) for x in options):
            raise ValueError("Each question must have four options.")
        answer = q.get("correct_answer")
        if answer not in options:
            raise ValueError("correct_answer must exactly match one option.")
    return data


def generate_quiz(text: str):
    prompt = f"""Generate exactly 3 multiple-choice questions from the passage below.
Each question must have exactly 4 plausible options and one correct answer.
Return ONLY valid JSON, with this exact shape:
{{"questions":[{{"question":"...","options":["...","...","...","..."],"correct_answer":"..."}}]}}
Passage:
{text}
"""
    raw = generate_text(prompt)
    try:
        data = json.loads(_clean_json_block(raw))
        return _validate_quiz(data)
    except (json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(f"Quiz generation returned invalid JSON: {exc}") from exc
